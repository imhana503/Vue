/* 신규 이용자 안내 패럴럭스 */
const userParallax = {  
    init:()=>{
        const userIntro = document.querySelector('.experience-intro');
        if( userIntro ){
            userParallax.horizontalEvent();
            userParallax.stepEvent();
        }
    },
    /* 이용자선택 이벤트 */
    stepEvent:()=>{
        const cardStep = document.querySelector('.card-step');
        const cardStepBtns = cardStep.querySelectorAll('.list button');
        const cardStepCont = cardStep.querySelectorAll('.img');

        cardStepBtns.forEach(function(btn, idx){
            btn.addEventListener('click', function(item){
                cardStepCont.forEach(function(cardCont){
                    cardCont.classList.remove('is-active');   
                });

                cardStepBtns.forEach(function(cardBtn){
                    cardBtn.closest('li').classList.remove('is-active');   
                });

                item.target.closest('li').classList.add('is-active');
                cardStepCont[idx].classList.add('is-active')
            })
        })
    },
    /* 좌우스크롤 이벤트 */
    horizontalEvent:()=>{
        const parallaxItemWrap = document.querySelector(".parallax-wrap");
        const parallaxItems = parallaxItemWrap.querySelectorAll('.parallax-item');
        const navigationBtns = document.querySelectorAll(".parallax-navigation a");
        const moveIcon = document.querySelector('.guide-move-icon');

        /* 좌우스크롤 이벤트  */
        gsap.to(parallaxItems, {
            xPercent: -100 * (parallaxItems.length - 1),
            ease: "none",
            scrollTrigger:{
                trigger: parallaxItemWrap,
                start: "top top",
                end: () => "+=" + (parallaxItemWrap.offsetWidth - innerWidth),
                pin: true,
                scrub: 1,
                snap:{
                    snapTo: 1/(parallaxItems.length -1), //크롤 위치를 요소들의 위치에 스냅하는 옵션입니다. 1 / (section.length - 1)은 각 요소 사이의 스냅 간격을 설정
                    // inertia: true, // 스냅 시의 관성 효과를 비활성화
                    duration: {min: 0.1, max: 0.1}, //스냅 애니메이션의 최소 및 최대 지속 시간을 설정
                },
                invalidateOnRefresh: true, //페이지 새로고침 시 스크롤 트리거 위치를 재계산하도록 설정
                anticipatePin: 1,
               
                onUpdate: (self) => {
                    const scrollProgress = self.progress * (parallaxItems.length - 1);
                    const activeIndex = Math.round(scrollProgress); //현재 index 값

                  
                    navigationBtns.forEach((btn, idx) => {
                        if (idx  === activeIndex) {userParallax.navigationEvent(btn, idx); }
                    });     

                    // 모든 섹션에서 클래스 제거
                    parallaxItems.forEach(item => item.classList.remove('is-active'));
                    
                     // 현재 활성화된 섹션에만 클래스 추가
                    parallaxItems[activeIndex].classList.add('is-active');

                    moveIcon.getAttribute = [];
                    moveIcon.setAttribute('parallaxIdx', `${activeIndex+1}`);
                },
               
            }
        });
        userParallax.navigationScrollEvent(); 
    },
    /* 네비게이션 클릭 좌우스크롤 이동 */
    navigationScrollEvent:()=>{
        const parallaxItems = document.querySelectorAll('.parallax-item');
        const navigationBtns = document.querySelectorAll(".parallax-navigation a");

        navigationBtns.forEach(function(btn, idx){
            btn.addEventListener('click', function(btnNav){
                const newXPercent = -100 * idx;
                gsap.to(parallaxItems, {
                    xPercent: newXPercent,
                    onComplete:function(){
                        userParallax.navigationEvent(btnNav.target, idx);
                    },
                    duration: 0.5, 
                    ease: "power2.inOut", 
                    
                });
            });
        })
    },
    /* 네비게이션 클릭 이벤트 */
    navigationEvent:(btn, idx)=>{
        const navigationBtns = document.querySelectorAll(".parallax-navigation a");

        navigationBtns.forEach(function(btnNavs){
            btnNavs.classList.remove('is-active');
        })
        btn.classList.add('is-active');       
    }
}

window.addEventListener('DOMContentLoaded', function(){
    experIntro.init();
    userParallax.init();
})